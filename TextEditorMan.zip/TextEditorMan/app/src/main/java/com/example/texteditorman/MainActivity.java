package com.example.texteditorman;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    RecyclerView textFileListView;
    Button searchBtn;
    EditText searchTextFileField;
    Intent in;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textFileListView=findViewById(R.id.textFileListView);
        searchBtn=findViewById(R.id.search_button);
        searchTextFileField=findViewById(R.id.searchTextFileField);
    }
}
