package com.example.texteditorman.Model;

public class FileBean
{
    String name,text,date,descirption;

    public FileBean(String name, String text, String date, String descirption) {
        this.name = name;
        this.text = text;
        this.date = date;
        this.descirption = descirption;
    }

    public FileBean(String name, String text) {
        this.name = name;
        this.text = text;
    }

    public FileBean() {
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescirption() {
        return descirption;
    }

    public void setDescirption(String descirption) {
        this.descirption = descirption;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
