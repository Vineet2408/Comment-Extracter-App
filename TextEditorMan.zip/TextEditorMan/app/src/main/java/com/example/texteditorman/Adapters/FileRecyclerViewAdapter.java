package com.example.texteditorman.Adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.texteditorman.Model.FileBean;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FileRecyclerViewAdapter extends RecyclerView.Adapter
{
    ArrayList<FileBean> list;
    Context context;

    public FileRecyclerViewAdapter(ArrayList<FileBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class FileRecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView Name,description,date;
        public FileRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
