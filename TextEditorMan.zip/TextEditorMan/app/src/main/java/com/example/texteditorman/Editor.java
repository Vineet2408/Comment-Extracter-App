package com.example.texteditorman;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.texteditorman.Model.FileBean;

public class Editor extends AppCompatActivity {
    EditText textField,nameField;

    Button editBtn,saveBtn;
    TextView tf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        textField=findViewById(R.id.textArea);
        editBtn=findViewById(R.id.editBtn);
        saveBtn=findViewById(R.id.saveBtn);
        nameField=findViewById(R.id.nameField);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=nameField.getText().toString();
                String text=textField.getText().toString();
                FileBean f=new FileBean(name,text);
            }
        });
    }
}
